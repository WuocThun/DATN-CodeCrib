<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>
    <div class="col-md-3 d-none d-md-block">
        <div class="card mb-3">
            <div class="card-body">
                <div>Số dư tài khoản</div>
                <h3 class="heading" style="margin-top: 0; margin-bottom: 0; color: #28a745;"><strong><?php echo e(number_format(auth()->user()->balance,0,',', '.')); ?> đ</strong></h3>
            </div>
        </div>
    </div>
    <div class="container">
        <h1>Chọn Gói VIP cho: <?php echo e($room->title); ?></h1>
        <?php $__currentLoopData = $vipPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card mb-3">
                <div class="card-body">
                    <h3 class="card-title"><?php echo e($package->name); ?></h3>
                    <p class="card-text"><strong>Giá:</strong> <?php echo e(number_format($package->price,0,',', '.')); ?> VND</p>
                    <p class="card-text"><strong>Thời gian:</strong> <?php echo e($package->duration_days); ?> ngày</p>
                    <p class="card-text"><strong>Lượt xem tăng:</strong> <?php echo e($package->boosted_views); ?></p>

                    <!-- Form để mua gói VIP -->
                    <form action="<?php echo e(route('admin.vip.purchase', [$room->id,$package->id])); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="vip_package_id" value="<?php echo e($package->id); ?>">
                        <button type="submit" class="btn btn-primary">Mua Gói</button>
                    </form>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin/content/vip/vip-packages.blade.php ENDPATH**/ ?>