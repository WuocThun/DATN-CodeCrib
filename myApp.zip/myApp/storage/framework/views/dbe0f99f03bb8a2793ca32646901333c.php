<?php $__env->startSection('main'); ?>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Thêm Tiện Ích Mới</h1>
        <a href="<?php echo e(route('admin.utilities.index')); ?>"><button class="btn mt-3 mb-3 btn-info">Danh sách các tiện ích</button></a>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Form Thêm Tiện Ích -->
        <form action="<?php echo e(route('admin.utilities.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-3">
                <label for="name" class="form-label">Tên Tiện Ích</label>
                <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" class="form-control" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label for="description" class="form-label">Mô Tả</label>
                <textarea id="description" name="description" class="form-control" rows="3"><?php echo e(old('description')); ?></textarea>
                <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="mb-3">
                <label for="icon" class="form-label">Icon (Font Awesome)</label>
                <input type="text" id="icon" name="icon" value="<?php echo e(old('icon')); ?>" class="form-control" placeholder="Nhập tên icon từ Font Awesome">
                <small class="form-text text-muted">Ví dụ: <strong>fas fa-wifi</strong> cho Wifi</small>
                <?php $__errorArgs = ['icon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="text-danger"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <button type="submit" class="btn btn-primary w-100">Thêm Tiện Ích</button>
        </form>
    </div>

    <!-- Thêm Bootstrap JS và Popper (cho các tính năng của Bootstrap) -->
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin_core/content/utility/create.blade.php ENDPATH**/ ?>