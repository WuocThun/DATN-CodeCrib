<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Cấp quyền cho User: <b> <?php echo e($user->name); ?></b>
                </div>
                <form action="<?php echo e(route('admin.insert_permission', $user->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <?php if(isset($name_roles)): ?>
                        Vai trò hiện tại của bạn: <b><?php echo e($name_roles); ?></b>
                    <?php endif; ?>
                    <?php $__currentLoopData = $permission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $per): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="form-check">
                            <input type="checkbox" class="form-check-input"
                                   <?php $__currentLoopData = @$get_permission_via_role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $get): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <?php if($get->id == $per->id): ?>
                                           checked
                                   <?php endif; ?>

                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                   name="permission[]" multiple value="<?php echo e($per->name); ?>"
                                   id="<?php echo e($per->id); ?>">
                            <label class="form-check-label" for="<?php echo e($per->id); ?>">
                                <?php echo e($per->name); ?>

                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>

                    <input type="submit" name="insertRole" value="Cấp quyền cho User" class="btn btn-primary">
                </form>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Thêm quyền cho user
                </div>
                <form action="<?php echo e(route('admin.add_permisission')); ?>" method="post">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleInputEmail1">Thêm quyền</label>
                        <input type="text" name="name" class="form-control" placeholder="....">
                    </div>

                    <br>

                    <input type="submit" name="insertRole" value="Thêm quyền" class="btn btn-primary">
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin/content/permissions/assgin_permission.blade.php ENDPATH**/ ?>