<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('main'); ?>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <style>
        .nameform {
            width: 30%;
        }
        #map {
            width: 100%;
            height: 400px;
            margin-top: 20px;
            border: 1px solid #ccc;
        }
    </style>

    <div class="container">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('admin.rooms.update', $room->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>

            <h1>Chọn địa điểm để xem bản đồ</h1>
            <label for="province">Tỉnh:</label>
            <select id="province" name="province">
                <option value="">Chọn tỉnh</option>
                <?php $__currentLoopData = $provinces['results']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($province['province_id']); ?>"><?php echo e($province['province_name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <label for="district">Quận:</label>
            <select id="district" name="district" disabled>
                <option value="">Chọn quận</option>
            </select>

            <label for="ward">Phường:</label>
            <select id="ward" name="ward" disabled>
                <option value="">Chọn phường</option>
            </select>

            <label for="street">Tên đường:</label>
            <input type="text" id="street" placeholder="Nhập tên đường..." />

            <label for="selectedInfo">Địa chỉ chính xác:</label>
            <input class="nameform" value="<?php echo e($room->full_address); ?>" name="full_address" type="text" id="selectedInfo" readonly />

            <h1>Thông tin mô tả</h1>
            <label for="rooms_class_id">Phân loại phòng mà bạn muốn đăng:</label>
            <select name="rooms_class_id">
                <option value="">Chọn loại phòng:</option>
                <?php $__currentLoopData = $getAllClassRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomsClass): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e($roomsClass->id == $room->rooms_class_id ? 'selected' : ''); ?> value="<?php echo e($roomsClass->id); ?>">
                        <?php echo e($roomsClass->title); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <div class="form-group">
                <label for="title">Tiêu đề:</label>
                <input type="text" onkeyup="ChangeToSlug();" id="slug" value="<?php echo e($room->title); ?>" name="title" />
                <input type="text" hidden name="slug" class="form-control" id="convert_slug" />
            </div>

            <div class="form-group">
                <label for="des_blog">Nhập mô tả về phòng:</label>
                <textarea class="des_blog form-control ckeditor" name="description" id="des_blog" rows="3"><?php echo e(old('description', $room->description)); ?></textarea>
            </div>

            <h1>Thông tin liên hệ</h1>
            <div class="form-group">
                <label>Thông tin liên hệ:</label>
                <input type="text" disabled value="<?php echo e($userData->name); ?>" />
            </div>
            <div class="form-group">
                <label>Số điện thoại:</label>
                <input type="text" disabled value="<?php echo e($userData->phone_number); ?>" />
            </div>
            <div class="form-group">
                <label>Diện tích:</label>
                <input type="text" name="area" value="<?php echo e(old('area', $room->area)); ?>" />
            </div>
            <div class="form-group">
                <label>Giá:</label>
                <input type="text" name="price" value="<?php echo e(old('price', $room->price)); ?>" />
            </div>

            <div class="form-group">
                <label>Đối tượng cho thuê:</label>
                <select name="gender_rental">
                    <option value="0" <?php echo e($room->gender_rental === 0 ? 'selected' : ''); ?>>-- Tất cả --</option>
                    <option value="1" <?php echo e($room->gender_rental === 1 ? 'selected' : ''); ?>>Nam</option>
                    <option value="2" <?php echo e($room->gender_rental === 2 ? 'selected' : ''); ?>>Nữ</option>
                </select>
            </div>

            <h1>Hình ảnh</h1>
            <?php
                $images = json_decode($room->image, true);
            ?>

            <?php if(!empty($images)): ?>
                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img width="200px" height="100px" src="<?php echo e(asset('uploads/rooms/' . $img)); ?>" alt="Room Image" />
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                <p>No images available</p>
            <?php endif; ?>

            <div class="form-group">
                <label for="">Hình ảnh:</label>
                <input type="file" name="image[]" class="form-control-image" multiple>
            </div>

            <div class="form-group">
                <label for="">Video URL:</label>
                <input type="text" name="video_url" class="form-control-image" /> <br>
                <label for="">Video:</label>
                <input type="file" name="video" class="form-control-image" />
            </div>

            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
            <input type="hidden" name="status" value="1">
            <button type="submit" class="btn btn-primary">Đăng bài</button>
            <?php endif; ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'houseRenter|viewer')): ?>
            <input type="hidden" name="status" value="0">
            <button type="submit" class="btn btn-warning">Gửi bài cho QTV</button>
            <?php endif; ?>
        </form>

        

    </div>

    <script>
        $(document).ready(function () {
            $('#province').change(function () {
                var provinceId = $(this).val();
                $('#district').prop('disabled', true).empty().append('<option value="">Chọn quận</option>');
                $('#ward').prop('disabled', true).empty().append('<option value="">Chọn phường</option>');

                if (provinceId) {
                    $.get('https://vapi.vnappmob.com/api/province/district/' + provinceId, function (data) {
                        $.each(data.results, function (index, district) {
                            $('#district').append('<option value="' + district.district_id + '">' + district.district_name + '</option>');
                        });
                        $('#district').prop('disabled', false);
                    });
                }
                updateMap();
            });

            $('#district').change(function () {
                var districtId = $(this).val();
                $('#ward').prop('disabled', true).empty().append('<option value="">Chọn phường</option>');

                if (districtId) {
                    $.get('https://vapi.vnappmob.com/api/province/ward/' + districtId, function (data) {
                        $.each(data.results, function (index, ward) {
                            $('#ward').append('<option value="' + ward.ward_id + '">' + ward.ward_name + '</option>');
                        });
                        $('#ward').prop('disabled', false);
                    });
                }
                updateMap();
            });

            $('#ward, #street').change(updateMap);

            function updateMap() {
                var provinceName = $('#province option:selected').text();
                var districtName = $('#district option:selected').text();
                var wardName = $('#ward option:selected').text();
                var streetName = $('#street').val();
                var fullAddress = `${streetName}${wardName ? ', ' + wardName : ''}${districtName ? ', ' + districtName : ''}${provinceName ? ', ' + provinceName : ''}`;

                $('#selectedInfo').val(fullAddress);
                $('input[name="full_address"]').val(fullAddress);

                if (fullAddress) {
                    const encodedAddress = encodeURIComponent(fullAddress);
                    const mapSrc = `https://maps.google.com/maps?width=600&height=400&hl=en&q=${encodedAddress}&t=&z=12&ie=UTF8&iwloc=B&output=embed`;
                    $('#map').attr('src', mapSrc);
                }
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin/content/rooms/edit.blade.php ENDPATH**/ ?>