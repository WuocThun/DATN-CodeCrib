<div class="results-right">
    <div class="modal fade" id="addMemberModal" tabindex="-1" aria-labelledby="addMemberModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addMemberModalLabel">Gửi nhận xét vào phòng</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="container mt-5">
                        <h1 class="text-center">Góp ý website</h1>
                        <?php $__errorArgs = ['g-recaptcha-response'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session('success')); ?>

                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('reviews.store')); ?>" method="POST" class="mt-4">
                            <?php echo csrf_field(); ?>
                            <!-- Đánh giá sao -->
                            <div class="mb-3">
                                <label for="rating" class="form-label">Đánh giá sao</label>
                                <div class="star-rating d-flex">
                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                        <i class="bi bi-star-fill inactive" data-value="<?php echo e($i); ?>"></i>
                                    <?php endfor; ?>
                                </div>
                                <input type="hidden" name="rating" id="rating" value="0">
                            </div>

                            <?php if(Auth::check()): ?>
                                <div class="mb-3">
                                    <p><strong>Tên:</strong> <?php echo e(Auth::user()->name); ?></p>
                                    <p><strong>Email:</strong> <?php echo e(Auth::user()->email); ?></p>
                                </div>
                            <?php else: ?>
                                <div class="mb-3">
                                    <label for="name" class="form-label">Tên</label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>

                                <div class="mb-3">
                                    <label for="email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                            <?php endif; ?>
                            <div class="mb-3">
                                <label for="comment" class="form-label">Nhận xét</label>
                                <textarea class="form-control" id="comment" name="comment" rows="4" required></textarea>
                            </div>

                            <br/>
                            <!-- Nút Gửi -->
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                            <input type="hidden" name="status" value="1">
                            <?php endif; ?>
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'houseRenter||viewer')): ?>
                            <input type="hidden" name="status" value="0">
                            <?php endif; ?>
                            <div class="d-grid">
                                <button type="submit" class="btn btn-danger">Gửi Đánh Giá</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <div class="filter-section">
        <h3>Nhập mật khẩu phòng trọ</h3>
        <form method="GET" action="<?php echo e(route('room-requests.index')); ?>">
            <div class="input-group mb-3">
                <input type="text" name="password" class="form-control" placeholder="Mật khẩu phòng trọ" aria-label="Nhập mật khẩu phòng trọ để lọc nhanh hơn" aria-describedby="basic-addon2" value="<?php echo e(request('password')); ?>">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="submit">Tìm kiếm</button>
                </div>
            </div>
            <h3>Tìm kiếm phòng trọ</h3>
            <div class="input-group mb-3">
                <input type="text" name="keyword" class="form-control" placeholder="Nhập từ khóa liên quan" aria-label="Nhập từ khóa tìm kiếm" aria-describedby="basic-addon2" value="<?php echo e(request('keyword')); ?>">
                <div class="input-group-append">
                    <button class="btn btn-outline-secondary" type="submit">Tìm kiếm</button>
                </div>
            </div>
        </form>
    </div>
    <div class="filter-section">
        <button class="btn btn-info" data-bs-toggle="modal" data-bs-target="#addMemberModal">Góp ý website
        </button>
    </div>
    <div class="filter-section">
        <h3>Danh mục cho tin cho thuê</h3>
        <ul>
            <li> <a class="filer_blogs" href="<?php echo e(url('/bo-loc/phong?min_price=0&max_price=1000000')); ?>">Dưới 1 triệu</a></li>
            <li>  <a class="filer_blogs" href="<?php echo e(url('/bo-loc/phong?min_price=1000000&max_price=2000000')); ?>"> 1 triệu - 2 triệu</a></li>
            <li> <a class="filer_blogs" href="<?php echo e(url('/bo-loc/phong?min_price=2000000&max_price=3000000')); ?>">2 triệu - 3 triệu</a></li>
            <li> <a class="filer_blogs" href="<?php echo e(url('/bo-loc/phong?min_price=3000000&max_price=5000000')); ?>">3 triệu - 5 triệu</a></li>
            <li> <a class="filer_blogs" href="<?php echo e(url('/bo-loc/phong?min_price=5000000')); ?>">Trên 5 triệu</a></li>
        </ul>
    </div>

    <div class="newstr">
        <h3>Phòng ngẫu nhiên</h3>
        <ul>
                <?php $__currentLoopData = $randomRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('getRoom',$room->slug)); ?>">
                    <img src=" <?php echo e(asset('uploads/fe/img/room1.jpg')); ?> " alt="Phòng trọ mới" />
                    <div>
                        <span class="post-meta"><?php echo e(\Illuminate\Support\Str::limit($room->title, 15, '...')); ?></span>
                        <span class="post-price"><?php echo e(number_format($room->price,0,',', '.')); ?> nghìn/tháng</span>

                    </div>
                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
    </div>
    <div class="newstr">
        <h3>Tin ngẫu nhiên</h3>
        <ul>
                <?php $__currentLoopData = $randomBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('getBlog',$blogs->slug)); ?>">
                    <img src=" <?php echo e(asset('uploads/fe/img/room1.jpg')); ?> " alt="Phòng trọ mới" />
                    <div>
                        <span class="post-meta"><?php echo e(\Illuminate\Support\Str::limit($blogs->title, 15, '...')); ?></span>


                    </div>
                </a>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </ul>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

<script>
    // JavaScript để xử lý đánh giá sao
    document.addEventListener('DOMContentLoaded', function () {
        const stars = document.querySelectorAll('.star-rating .bi-star-fill');
        const ratingInput = document.getElementById('rating');

        stars.forEach(star => {
            star.addEventListener('click', function () {
                const value = this.getAttribute('data-value');
                ratingInput.value = value;

                stars.forEach(s => {
                    if (s.getAttribute('data-value') <= value) {
                        s.classList.remove('inactive');
                    } else {
                        s.classList.add('inactive');
                    }
                });
            });
        });
    });
</script>
<?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/fe/inc/fitler_blogs_right.blade.php ENDPATH**/ ?>