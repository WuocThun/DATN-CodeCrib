<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">Thêm danh mục <phòng></phòng> </div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                            <a href="<?php echo e(route('admin.rooms_classification.index')); ?>" class="btn btn-warning">Tất cả danh mục </a>

                        <form action="<?php echo e(route('admin.rooms_classification.store')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Tên Danh mục</label>
                                <input type="text"  name="title" class="form-control" placeholder="...."
                                       onkeyup="ChangeToSlug();" id="slug">
                            </div>


                                <input type="text" name="slug" hidden class="form-control" placeholder="...." id="convert_slug">


                            <div class="form-group">
                                <label for="exampleInputPassword1">Description</label>
                                <textarea class="des_blog form-control ckeditor" name="description"
                                          id="des_blog"
                                          rows="3"></textarea>
                            </div>

                            <button type="submit" class="btn btn-warning">Thêm danh mục</button>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin/content/rooms_classification/create.blade.php ENDPATH**/ ?>