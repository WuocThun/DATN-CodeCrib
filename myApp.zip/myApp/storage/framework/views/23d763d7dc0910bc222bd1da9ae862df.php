<?php $__env->startSection('main'); ?>

    <main role="main" class="ml-sm-auto col">
        <?php echo $__env->make('admin_core.inc.sub_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('error')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <?php if(isset($motel)): ?>
            <div class="row">

                <div class="col-md-4 mb-3">
                    <div class="card room-card">
                        <!-- Header -->
                        <div class="card-header text-center bg-warning">
                            <img class="img-fluid" src="<?php echo e(asset('uploads/logoCodeCrib.png')); ?>">
                        </div>
                        <!-- Body -->
                        <div class="card-body">
                            <h6 class="room-name"><?php echo e($motel->name); ?></h6>
                            <ol class="list-group list-group-numbered">
                                <li class="list-group-item d-flex justify-content-between align-items-start center">
                                    <div class="ms-2 me-auto">
                                        <div class="fw-bold">Nhập mật khẩu để mở khoá</div>
                                        <button type="button" class="fs-m btn-info" data-bs-toggle="modal"
                                                data-bs-target="#requestModal<?php echo e($motel->id); ?>">
                                            Tại đây
                                        </button>
                                    </div>
                                </li>
                            </ol>
                            <div class="modal fade" id="requestModal<?php echo e($motel->id); ?>" tabindex="-1"
                                 aria-labelledby="requestModalLabel<?php echo e($motel->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="requestModalLabel<?php echo e($motel->id); ?>">Danh sách yêu
                                                cầu tham gia phòng</h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('admin.check.passcode')); ?>" method="POST">
                                                <?php echo csrf_field(); ?>

                                                <div class="mb-3">
                                                    <label for="motel_id" class="form-label text-dark">Tên
                                                        phòng: <?php echo e($motel->name); ?></label>

                                                    <input type="text" name="motel_id" hidden value="<?php echo e($motel->id); ?>"
                                                           id="">
                                                </div>

                                                <div class="mb-3">
                                                    <label for="password" class="form-label text-dark">Nhập
                                                        password</label>
                                                    <input type="text" class="form-control" id="password"
                                                           name="password" required>
                                                </div>

                                                <button type="submit" class="btn btn-primary">Kiểm Tra</button>
                                            </form>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                                                Đóng
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="viewContract<?php echo e($motel->id); ?>" tabindex="-1"
                                 aria-labelledby="viewContractLabel<?php echo e($motel->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="viewContractLabel<?php echo e($motel->id); ?>">Xem hợp đồng <?php echo e($motel->name); ?></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <?php if($motel->contracts->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $motel->contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <p><strong>Tên người thuê:</strong> <?php echo e($contract->tenant_name); ?></p>
                                                    <p><strong>Tên chủ trọ:</strong> <?php echo e($contract->owner_name); ?></p>
                                                    <p><strong>Ngày bắt đầu:</strong> <?php echo e($contract->start_date); ?></p>
                                                    <p><strong>Ngày kết thúc:</strong> <?php echo e($contract->end_date); ?></p>

                                                    <?php if($contract->contract_image): ?>
                                                        <p><strong>Ảnh chứng minh:</strong></p>
                                                        <?php $__currentLoopData = json_decode($contract->contract_image, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <img src="<?php echo e(asset('uploads/contracts/' . $image)); ?>" alt="Hợp đồng" style="width: 100%; max-width: 300px; margin-bottom: 10px;">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endif; ?>

                                                    <?php if($contract->contract_file): ?>
                                                        <p><strong>Hợp đồng file:</strong>
                                                            <a href="<?php echo e(asset($contract->contract_file)); ?>" target="_blank">Xem file hợp đồng</a>
                                                        </p>
                                                    <?php endif; ?>

                                                    <hr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <p>Hợp đồng chưa được chủ phòng tạo</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="shareHome<?php echo e($motel->id); ?>" tabindex="-1"
                                 aria-labelledby="shareHomeLabel<?php echo e($motel->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="shareHomeLabel<?php echo e($motel->id); ?>">Đăng tin kiếm người ở ghép: <strong> <?php echo e($motel->name); ?> </strong></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?php echo e(route('admin.requests.create')); ?>" method="POST" enctype="multipart/form-data">
                                                <?php echo csrf_field(); ?>
                                                <div class="mb-3">
                                                    <label for="motel_id" class="form-label">Phòng Trọ</label>
                                                        <select class="form-select" name="motel_id" required>
    
                                                                <option value="<?php echo e($motel->id); ?>"><?php echo e($motel->name); ?></option>
    
                                                        </select>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="title" class="form-label">Tiêu Đề</label>
                                                    <input type="text" class="form-control" name="title" required>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="description" class="form-label">Mô Tả</label>
                                                    <textarea class="form-control" name="description" rows="4"></textarea>
                                                </div>
                                                <div class="mb-3">
                                                    <label for="contract_image" class="form-label">Tải ảnh phòng hiện tại</label>
                                                    <input type="file" class="form-control" id="contract_image"
                                                           name="image[]" multiple>
                                                </div>
                                                <button type="submit" class="btn btn-primary">Đăng Bài</button>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="modal fade" id="invitedUser<?php echo e($motel->id); ?>" tabindex="-1"
                                 aria-labelledby="invitedUserLabel<?php echo e($motel->id); ?>" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="invitedUserLabel<?php echo e($motel->id); ?>">Mời người dùng vào phòng: <strong> <?php echo e($motel->name); ?> </strong></h5>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            <!-- Form tìm kiếm người dùng -->
                                            <form id="searchUserForm<?php echo e($motel->id); ?>">
                                                <?php echo csrf_field(); ?>
                                                <div class="mb-3">
                                                    <label for="rand_code_user" class="form-label">Nhập mã người dùng</label>
                                                    <input type="text" class="form-control" id="rand_code_user<?php echo e($motel->id); ?>" name="rand_code_user" required>
                                                </div>
                                                <button type="button" class="btn btn-primary" onclick="searchUser(<?php echo e($motel->id); ?>)">Tìm kiếm</button>
                                            </form>

                                            <!-- Hiển thị kết quả tìm kiếm -->
                                            <div id="userInfo<?php echo e($motel->id); ?>" style="display: none;">
                                                <hr>
                                                <h5>Thông tin người dùng</h5>
                                                <p id="userName<?php echo e($motel->id); ?>"></p>
                                                <p id="userEmail<?php echo e($motel->id); ?>"></p>
                                                <p id="userPhone<?php echo e($motel->id); ?>"></p>

                                                <!-- Gửi lời mời -->
                                                <form action="<?php echo e(route('invite-user')); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <input type="hidden" name="motel_id" value="<?php echo e($motel->id); ?>">
                                                    <input type="hidden" id="user_id<?php echo e($motel->id); ?>" name="user_id">
                                                    <button type="submit" class="btn btn-success">Mời tham gia</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="room-info my-3">
                                <?php if(session("motel_unlocked_{$motel->id}")): ?>
                                    <div class="actions d-flex justify-content-between">
                                        <button class="btn btn-info"
                                                onclick="window.location.href='<?php echo e(route('admin.motel.addUserMotel', ['id' => $motel->id])); ?>'">
                                            <i class="fas fa-user-friends"></i>
                                        </button>
                                        <?php if(isset($motel->getInvoicesBy($motel->id)->first()->id)): ?>
                                            <button class="btn btn-warning"
                                                    onclick="window.location.href='<?php echo e(route('admin.invoices.pay', ['id' => $motel->getInvoicesBy($motel->id)->first()->id])); ?>'">
                                                <i class="fas fa-receipt"></i>
                                            </button>
                                        <?php endif; ?>
                                        <button class="btn btn-primary" data-bs-toggle="modal"
                                                data-bs-target="#viewContract<?php echo e($motel->id); ?>">
                                            <i  class='fas fa-file-contract'></i>
                                        </button>
                                        <button class="btn btn-secondary" data-bs-toggle="modal"
                                                data-bs-target="#shareHome<?php echo e($motel->id); ?>">
                                            <i class="fas fa-share"></i>
                                        </button>
                                        <button class="btn btn-warning position-relative" data-bs-toggle="modal"
                                                data-bs-target="#invitedUser<?php echo e($motel->id); ?>">
                                            <i class="fas fa-plus"></i>
                                        </button>

                                        <form action="<?php echo e(route('admin.motel.leave')); ?>"
                                              method="POST" style="display: inline;">
                                            <?php echo csrf_field(); ?>

                                            <button type="submit" class="btn btn-danger"
                                                    onclick="return confirm('Bạn có muốn thoát phòng không?')">
                                                <i class="fas fa-sign-out-alt"></i></button>
                                        </form>
                                    </div>
                                <?php else: ?>
                                    <p class="text-danger">Bạn cần nhập đúng mật khẩu để mở khóa phòng.</p>
                                <?php endif; ?>
                            </div>

                            <div class="card-footer text-center row">
                                <div class="col-md-6  ">
                                    <p>Ngày tính
                                        tiền: <?php echo e(\Carbon\Carbon::parse($motel->money_date)->format('d/m/Y')); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p>Tiền phòng: <?php echo e(number_format($motel->money,0,',', '.')); ?> đ</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>

            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <div class="card room-card">
                        <!-- Header -->
                        <div class="card-header text-center bg-warning">
                            <img class="img-fluid" src="<?php echo e(asset('uploads/logoCodeCrib.png')); ?>">
                        </div>
                        <!-- Body -->
                        <div class="card-body">
                            <h6 class="room-name">Bạn chưa có phòng nào hết, mau đăng ký lẹ đi</h6>

                            <div class="card-footer text-center row">
                            </div>
                        </div>
                    </div>
                    <!-- End Card -->
                </div>

            </div>

        <?php endif; ?>
    </main>
    <script>
        function searchUser(motelId) {
            const randCode = document.getElementById(`rand_code_user${motelId}`).value;

            fetch('<?php echo e(route("search-user")); ?>', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                },
                body: JSON.stringify({ rand_code_user: randCode }),
            })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        alert(data.error);
                    } else {
                        document.getElementById(`userInfo${motelId}`).style.display = 'block';
                        document.getElementById(`userName${motelId}`).innerText = `Tên: ${data.user.name}`;
                        document.getElementById(`userEmail${motelId}`).innerText = `Email: ${data.user.email}`;
                        document.getElementById(`userPhone${motelId}`).innerText = `Số điện thoại: ${data.user.phone_number}`;
                        document.getElementById(`user_id${motelId}`).value = data.user.id;
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        }

    </script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin_core/content/motel/room-access.blade.php ENDPATH**/ ?>