<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('fe.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="container">

        <h1>Bài Đăng Tìm Người Ở Cùng</h1>

        <div class="container search-results-container">

            <div class="results-left">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>    <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <?php echo e(session('error')); ?>

                    </div>
                <?php endif; ?>
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <div class="card mb-4 shadow-sm" style="max-width: 600px; margin: auto;">
                        <?php if($room->image): ?>
                            <div id="roomImagesCarousel-<?php echo e($room->id); ?>" class="carousel slide" data-bs-ride="carousel">
                                <div class="carousel-inner">
                                    <?php $__currentLoopData = json_decode($room->image, true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="carousel-item <?php echo e($index === 0 ? 'active' : ''); ?>">
                                            <img class="d-block w-100" src="<?php echo e(asset($image)); ?>"
                                                 alt="Image <?php echo e($index + 1); ?>" style="height: 300px; object-fit: cover;">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- Điều khiển slider -->
                                <button class="carousel-control-prev" type="button"
                                        data-bs-target="#roomImagesCarousel-<?php echo e($room->id); ?>" data-bs-slide="prev">
                                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Previous</span>
                                </button>
                                <button class="carousel-control-next" type="button"
                                        data-bs-target="#roomImagesCarousel-<?php echo e($room->id); ?>" data-bs-slide="next">
                                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                    <span class="visually-hidden">Next</span>
                                </button>
                            </div>
                        <?php else: ?>
                            <div class="card-header text-center bg-info">
                                <div class="row">
                                </div>
                                <img class="img-fluid" src="<?php echo e(asset('uploads/logoCodeCrib.png')); ?>"
                                     style="height: 300px; object-fit: contain;">
                            </div>
                        <?php endif; ?>
                        <div class="card-body">
                            <h5 class="card-title text-truncate"><?php echo e($room->title); ?></h5>
                            <p class="card-text text-muted mb-2">
                                <?php echo e(number_format($room->motel->money, 0, ',', '.')); ?> nghìn/tháng - <?php echo e($room->area); ?>m²
                            </p>
                            <p class="card-text text-muted mb-2"><?php echo e($room->full_address); ?></p>
                            <p class="card-text text-truncate"><?php echo e(\Illuminate\Support\Str::limit($room->description, 50, '...')); ?></p>
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin||viewer')): ?>
                            <div class="d-flex justify-content-between align-items-center">
                                <form action="<?php echo e(route('room-requests.store')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="motel_id" value="<?php echo e($room->motel->id); ?>">
                                    <button type="submit" class="btn btn-warning">Yêu cầu tham gia</button>
                                </form>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="pagination">
                    <?php if($requests->onFirstPage()): ?>
                        <button class="prev" disabled>« Trang trước</button>
                    <?php else: ?>
                        <a href="<?php echo e($requests->previousPageUrl()); ?>" class="prev">« Trang trước</a>
                    <?php endif; ?>

                    <?php for($page = 1; $page <= $requests->lastPage(); $page++): ?>
                        <a href="<?php echo e($requests->url($page)); ?>"
                           class="page <?php echo e($page == $requests->currentPage() ? 'active' : ''); ?>"><?php echo e($page); ?></a>
                    <?php endfor; ?>

                    <?php if($requests->hasMorePages()): ?>
                        <a href="<?php echo e($requests->nextPageUrl()); ?>" class="next">Trang sau »</a>
                    <?php else: ?>
                        <button class="next" disabled>Trang sau »</button>
                    <?php endif; ?>
                </div>
            </div>

            <?php echo $__env->make('fe.inc.fitler_blogs_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('fe.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/fe/kiemnguoioghep.blade.php ENDPATH**/ ?>