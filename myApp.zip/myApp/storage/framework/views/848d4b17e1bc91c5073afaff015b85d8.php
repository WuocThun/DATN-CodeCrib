<?php $__env->startSection('main'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Danh Sách Tin thuê phòng đợi duyệt</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <table class="table">
                            <thead>
                            <tr>
                                <table id="myTable" class="table">
                                    <thead>
                                    <th scope="col">ID</th>
                                    <th scope="col">Tên Phòng</th>
                                    <th scope="col">Mô tả</th>
                                    <th scope="col">Trạng thái</th>
                                    <th scope="col">Ngày đăng</th>
                                    <th scope="col">Hình ảnh</th>
                                    <th scope="col">Hành động</th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$myroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($myroom->id); ?></td>
                                            <td><?php echo e($myroom->title); ?></td>
                                            <td><?php echo e(\Illuminate\Support\Str::limit($myroom->description, 15, '...')); ?></td>
                                            <td>
                                                <?php if($myroom->status == 1): ?>
                                                    <p class="text-success btn">Phòng đã được duyệt </p>
                                                <?php elseif($myroom->status == 0): ?>

                                                    <p class="text-warning btn">Phòng đang đợi QTV duyệt</p>
                                                <?php elseif($myroom->status == 3): ?>
                                                    <p class="text-danger btn">Phòng đã bị từ chối</p>
                                                <?php else: ?>
                                                    <p class="text-danger btn">Phòng Không hiển thị </p>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($myroom->created_at); ?></td>
                                            <td>
                                                <?php
                                                    // Decode the JSON data for images
                                                    $images = json_decode($myroom->image, true);
                                                ?>

                                                <?php if(!empty($images)): ?>
                                                    <?php if(count($images) === 1): ?>
                                                        <!-- Display a single image -->
                                                        <img width="200px" height="100px" src="<?php echo e(asset('uploads/rooms/' . json_decode( $myroom->image))); ?>" alt="Room Image">
                                                    <?php else: ?>
                                                        <!-- Bootstrap Carousel for Multiple Images -->
                                                        <div id="carousel-<?php echo e($myroom->id); ?>" class="carousel slide" data-bs-ride="carousel">
                                                            <div class="carousel-inner">
                                                                <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                                                        <img width="200px" height="100px" src="<?php echo e(asset('uploads/rooms/' . $img)); ?>" alt="Room Image">
                                                                    </div>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </div>
                                                            <!-- Controls -->
                                                            <button class="carousel-control-prev" type="button" data-bs-target="#carousel-<?php echo e($myroom->id); ?>" data-bs-slide="prev">
                                                                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                                <span class="visually-hidden">Previous</span>
                                                            </button>
                                                            <button class="carousel-control-next" type="button" data-bs-target="#carousel-<?php echo e($myroom->id); ?>" data-bs-slide="next">
                                                                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                                <span class="visually-hidden">Next</span>
                                                            </button>
                                                        </div>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    <p>No images available</p>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                
                                                
                                                <a class="btn btn-warning"  href="<?php echo e(route('admin.rooms.viewPendingRooms',[$myroom->id])); ?>">Xem bài đăng</a>
                                                <form method="post" action="<?php echo e(route('admin.room.accpectRoom', $myroom->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-success">Duyệt bài đăng</button>
                                                </form>
                                                <form method="post" action="<?php echo e(route('admin.room.denialRoom', $myroom->id)); ?>">
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-info">Từ chối</button>
                                                </form>

                                                <form method="post"  action="<?php echo e(route('admin.rooms.destroy',[$myroom->id])); ?>">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button onclick="return confirm('Bạn có muốn xoá?')" class="btn btn-danger">Xoá</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                </th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin/content/rooms/pending_rooms.blade.php ENDPATH**/ ?>