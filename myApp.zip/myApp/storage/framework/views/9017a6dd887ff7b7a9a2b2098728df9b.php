<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">Cập nhật bài viết </div>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                            <?php if($blog->status == 3): ?>
                                <p class="text-danger">Lý do từ chối: <?php echo e($blog->reject_reason); ?></p>
                            <?php endif; ?>

                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                            <a href="<?php echo e(route('admin.blogs.index')); ?>" class="btn btn-info">Danh sách bài viết </a>
                            <?php endif; ?>
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'houseRenter|viewer')): ?>
                            <a href="<?php echo e(route('admin.blogs.myblogs')); ?>" class="btn btn-info">Danh sách bài viết </a>

                            <?php endif; ?>
                        <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-success">Thêm bài viết </a>

                        <form action="<?php echo e(route('admin.blogs.update',$blog->id)); ?>" method="post"
                              enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Title</label>
                                <input type="text" name="title" required class="form-control" value="<?php echo e($blog->title); ?>"
                                       onkeyup="ChangeToSlug();" id="slug">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">slug</label>
                                <input type="text"  name="slug" required class="form-control" value="<?php echo e($blog->slug); ?>"
                                       id="convert_slug">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputEmail1">Image</label> <br>

                                <input type="file" name="image" class="form-control-image" id="">
                                <img width="200px" height="100px"
                                     src="<?php echo e(asset('uploads/blogs/'.$blog->image)); ?>" alt="">
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Description</label>
                                <textarea class="des_blog form-control ckeditor"  name="description"
                                          id="des_blog"
                                          rows="3"><?php echo e($blog->description); ?></textarea>
                            </div>

                            <div class="form-group">
                                <label for="exampleInputPassword1">Content</label>
                                <textarea class="form-control" required name="content"
                                          id="exampleFormControlTextarea1"
                                          rows="3"><?php echo e($blog->content); ?></textarea>
                            </div>
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                            <div class="form-group">
                                <input name="status" hidden="" type="number"  value="1">
                            </div>
                            <?php endif; ?>
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'houseRenter|viewer')): ?>
                            <div class="form-group">
                                <input name="status" hidden="" type="number"  value="2">
                            </div>
                            <?php endif; ?>
                            <br>
                            <?php if($blog->status == 3 ): ?>
                            <button type="submit" class="btn btn-danger">Sửa lỗi</button>
                            <?php else: ?>
                                <button type="submit" class="btn btn-primary">Chỉnh sửa</button>
                            <?php endif; ?>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin/content/blogs/edit.blade.php ENDPATH**/ ?>