<?php $__env->startSection('main'); ?>
    <div class="container mt-5">
        <h1 class="mb-4">Danh Sách Bình Luận</h1>

        <!-- Bộ lọc -->
        <form method="GET" action="<?php echo e(route('admin.comments.listAllComtent')); ?>" class="mb-4">
            <div class="row">
                <div class="col-md-12 mb-3">
                    <select name="room_id" class="form-select">
                        <option value="">Tất cả phòng</option>
                        <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($room->id); ?>" <?php echo e($roomId == $room->id ? 'selected' : ''); ?>>
                                <?php echo e($room->title); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-4">
                    <button type="submit" class="btn btn-primary">Lọc</button>
                </div>
            </div>
        </form>

        <!-- Hiển thị danh sách bình luận -->
        <table class="table table-striped">
            <thead>
            <tr>
                <th>ID</th>
                <th>Người dùng</th>
                <th>Nội dung</th>
                <th>Số sao</th>
                <th>Phòng</th>
                <th>Ngày tạo</th>
            </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($comment->id); ?></td>
                    <td><?php echo e($comment->user->name); ?></td>
                    <td><?php echo e($comment->content); ?></td>
                    <td><?php echo e($comment->rating); ?></td>
                    <td><?php echo e($comment->room ? $comment->room->title : 'Không có'); ?></td>
                    <td><?php echo e($comment->created_at); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="text-center">Không có bình luận nào.</td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin_core/content/comments/index.blade.php ENDPATH**/ ?>