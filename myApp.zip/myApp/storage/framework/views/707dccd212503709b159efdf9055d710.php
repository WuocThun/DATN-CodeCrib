<?php $__env->startSection('title','Tin tức'); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('fe.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('searchBar'); ?>
    <?php echo $__env->make('fe.inc.search_bar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('hotZone'); ?>
    <?php echo $__env->make('fe.inc.hot_zone', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <section class="search-results">
        <div class="container search-results-container">
            <div class="results-left">
                <div style="margin-bottom: 20px; ">
                    <a href="<?php echo e(route('welcome')); ?>" style="text-decoration: none; ">Trang chủ</a> > Tin tức
                </div>
                <h2 style="margin-bottom: 20px;">Tin tức thị trường, chia sẻ kinh nghiệm Bất động sản</h2>
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <a href="<?php echo e(route('getBlog',$blog->slug)); ?>" style="text-decoration: none;">
                    <div class="result-item">
                        <img src="<?php echo e(asset('uploads/blogs/'.$blog->image)); ?>" alt="Ký túc xá Tân Bình">
                        <div class="result-info">
                            <h3><?php echo e($blog->title); ?></h3>
                            <p><?php echo e(\Illuminate\Support\Str::limit($blog->content, 100)); ?></p>
                            <div class="contact-options">

                            </div>
                        </div>
                    </div>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="pagination">
                    <?php if($blogs->onFirstPage()): ?>
                        <button class="prev" disabled>« Trang trước</button>
                    <?php else: ?>
                        <a href="<?php echo e($blogs->previousPageUrl()); ?>" class="prev">« Trang trước</a>
                    <?php endif; ?>

                    <?php for($page = 1; $page <= $blogs->lastPage(); $page++): ?>
                        <a href="<?php echo e($blogs->url($page)); ?>" class="page <?php echo e($page == $blogs->currentPage() ? 'active' : ''); ?>"><?php echo e($page); ?></a>
                    <?php endfor; ?>

                    <?php if($blogs->hasMorePages()): ?>
                        <a href="<?php echo e($blogs->nextPageUrl()); ?>" class="next">Trang sau »</a>
                    <?php else: ?>
                        <button class="next" disabled>Trang sau »</button>
                    <?php endif; ?>
                </div>
            </div>

           <?php echo $__env->make('fe.inc.fitler_blogs_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('overView'); ?>
    <?php echo $__env->make('fe.inc.over_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('fe.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('fe.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/fe/tintuc.blade.php ENDPATH**/ ?>