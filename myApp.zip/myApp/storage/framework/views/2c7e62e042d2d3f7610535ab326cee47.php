<?php $__env->startSection('main'); ?>
    <div class="container">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Cấp quyền cho User: <b> <?php echo e($user->name); ?></b>
                </div>
                <form action="<?php echo e(route('admin.insert_roles', $user->id)); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                    <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(isset($all_collum_roles)): ?>

                            <div class="form-check form-check-inline">
                                <input class="form-check-input"
                                       <?php echo e($r->id==$all_collum_roles->id ? 'checked' : ''); ?>  type="radio" name="role"
                                       id="<?php echo e($r->id); ?>" value="<?php echo e($r->name); ?>">
                                <label class="form-check-label" for="<?php echo e($r->id); ?>"><?php echo e($r->name); ?> </label>
                            </div>
                        <?php else: ?>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input"
                                       type="radio" name="role"
                                       id="<?php echo e($r->id); ?>" value="<?php echo e($r->name); ?>">
                                <label class="form-check-label" for="<?php echo e($r->id); ?>"><?php echo e($r->name); ?> </label>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    
                    
                    
                    
                    
                    
                    
                    
                    <input type="submit" name="insertRole" value="Cấp vai trò cho User" class="btn btn-primary">
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin/content/permissions/assgin.blade.php ENDPATH**/ ?>