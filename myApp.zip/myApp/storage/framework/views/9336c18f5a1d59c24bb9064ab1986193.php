<?php $__env->startSection('main'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Danh Sách phân loại phòng</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <a href="<?php echo e(route('admin.rooms_classification.create')); ?>" class="btn btn-success"> Thêm Danh mục phòng </a>
                        <table class="table">
                            <thead>
                            <tr>
                                <table id="myTable" class="table">
                                    <thead>
                                    <th scope="col">ID</th>
                                    <th scope="col">Tên danh mục</th>
                                    <th scope="col">Có bao nhiêu phòng thuộc</th>
                                    <th scope="col">Quản lý</th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $getRoomsClassification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$classification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($key+1); ?></th>
                                            <td><?php echo e($classification->title); ?></td>
                                            <td><?php echo e($classification->rooms_count); ?></td> <!-- Số lượng phòng -->

                                            <td>
                                                <a class="btn btn-warning"  href="<?php echo e(route('admin.rooms_classification.edit',$classification->id)); ?>">Sửa</a>
                                                <form method="post"  action="<?php echo e(route('admin.rooms_classification.destroy',[$classification->id])); ?>">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button onclick="return confirm('Bạn có muốn xoá?')" class="btn btn-danger">Xoá</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                </th>
                            </tr>
                            </thead>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin/content/rooms_classification/index.blade.php ENDPATH**/ ?>