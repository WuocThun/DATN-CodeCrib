<?php $__env->startSection('main'); ?>
    <main role="main" class="ml-sm-auto col">

        <div class="container">
            <h1>Danh Sách Hợp Đồng</h1>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>#</th>
                    <th>Người Thuê</th>
                    <th>Chủ Trọ</th>
                    <th>Ngày Bắt Đầu</th>
                    <th>Ngày Kết Thúc</th>
                    <th>Trạng Thái</th>
                    <th>Hành Động</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $contracts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contract): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($contract->id); ?></td>
                        <td><?php echo e($contract->tenant_name); ?></td>
                        <td><?php echo e($contract->owner_name); ?></td>
                        <td><?php echo e($contract->start_date); ?></td>
                        <td><?php echo e($contract->end_date); ?></td>
                        <td><?php echo e($contract->status); ?></td>
                        <td>
                            <a href="<?php echo e(asset($contract->contract_file)); ?>" target="_blank" class="btn btn-sm btn-success">
                                Xem Hợp Đồng
                            </a>
                        </td>
                        <td>
                            <?php if(!empty($contract->contract_image)): ?>
                                <?php
                                    $images = is_array(json_decode($contract->contract_image, true))
                                              ? json_decode($contract->contract_image, true)
                                              : [$contract->contract_image]; // Đưa vào mảng nếu là string
                                ?>

                                <?php if(count($images) > 1): ?>
                                    <!-- Hiển thị nhiều ảnh -->
                                    <div class="row">
                                        <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-md-3">
                                                <div class="card mb-3">
                                                    <img src="<?php echo e(asset('uploads/contracts/' . $image)); ?>" class="card-img-top" alt="Contract Image">
                                                    <div class="card-body text-center">
                                                        <button class="btn btn-danger btn-sm delete-image" data-image="<?php echo e($image); ?>">Xóa</button>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                <?php else: ?>
                                    <!-- Hiển thị một ảnh -->
                                    <div class="text-center">
                                        <img src="<?php echo e(asset('uploads/contracts/' . $images[0])); ?>" class="img-fluid rounded" alt="Contract Image">
                                    </div>
                                <?php endif; ?>
                            <?php endif; ?>

                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>


            <?php echo e($contracts->links()); ?>

        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin_core/content/contracts/create.blade.php ENDPATH**/ ?>