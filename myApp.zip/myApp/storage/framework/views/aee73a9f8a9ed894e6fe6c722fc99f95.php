<?php $__env->startSection('main'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Danh Sách Blog</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <a href="<?php echo e(route('admin.blogs.create')); ?>" class="btn btn-success"> Thêm Blog </a>
                        <table class="table">
                            <thead>
                            <tr>
                                <table id="myTable" class="table">
                                    <thead>
                                    <th scope="col">ID</th>
                                    <th scope="col">Tên danh mục</th>
                                    <th scope="col">Mô tả</th>
                                    <th scope="col">Hiển thị</th>
                                    <th scope="col">Loại tin</th>
                                    <th scope="col">Ngày đăng</th>
                                    <th scope="col">Hình ảnh</th>
                                    <th scope="col">Hành động</th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($key+1); ?></th>
                                            <td><?php echo e($cate->title); ?></td>
                                            <td><?php echo e(\Illuminate\Support\Str::limit($cate->description, 50, '...')); ?></td>
                                            <td>
                                                <?php if($cate->status == 1): ?>
                                                    <p class="text-success btn">Hiển thị </p>
                                                <?php elseif($cate->status == 0): ?>
                                                    <p class="text-danger btn">Không hiện thị </p>
                                                <?php elseif($cate->status == 3): ?>
                                                    <p class="text-danger btn">Từ chối</p>
                                                <?php else: ?>
                                                    <p class="text-warning btn">Đợi duyệt</p>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php if($cate->kind_of_blog == "blogs"): ?>
                                                    Blog
                                                <?php else: ?>
                                                    Hướng dẫn
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($cate->created_at); ?></td>
                                            <td><img width="200px" height="100px"
                                                     src="<?php echo e(asset('uploads/blogs/'.$cate->image)); ?>" alt=""></td>
                                            <td>
                                                <a class="btn btn-secondary"
                                                   href="<?php echo e(route('admin.blogs.preview_blogs',$cate->id)); ?>">xem Blogs</a>
                                                <a class="btn btn-warning"  href="<?php echo e(route('admin.blogs.edit',$cate->id)); ?>">Sửa</a>
                                                
                                                <form method="post"  action="<?php echo e(route('admin.blogs.destroy',[$cate->id])); ?>">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button onclick="return confirm('Bạn có muốn xoá?')" class="btn btn-danger">Xoá</button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                </th>
                            </tr>
                            </thead>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin/content/blogs/myblogs.blade.php ENDPATH**/ ?>