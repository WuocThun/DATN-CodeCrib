<?php $__env->startSection('main'); ?>

    <main role="main" class="ml-sm-auto col">
        <?php echo $__env->make('admin_core.inc.sub_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <h2>Hoá đơn</h2>
            </div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                    <tr>
                        <th scope="col">Phòng</th>
                        <th scope="col">Trạng thái</th>
                        <th scope="col">Tổng tiền</th>
                        <th scope="col">Ngày tạo hoá đơn</th>
                        <th scope="col">Hành động</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><?php echo e($data->motel->name); ?></th>
                            <?php if($data->status == 'paid'): ?>
                                <td><span class="badge badge-warning">Da thanh toan</span></td>
                            <?php else: ?>
                                <td><span class="badge badge-primary">chua thanh toan</span></td>
                            <?php endif; ?>
                            <td><?php echo e(number_format($data->total_amount,0,',', '.')); ?> VNĐ</td>
                            <td><?php echo e(\Carbon\Carbon::parse($data->created_at)->format('d/m/Y')); ?></td>
                            <td>
                                <div class="row">
                                    <button class="btn btn-success ml-3"
                                            onclick="window.location.href='<?php echo e(route('admin.invoices.pay',['id'=>$data->id])); ?>'">
                                        <i class="fas fa-money-check"></i>
                                    </button>
                                    
                                    <button class="btn btn-info ml-3">
                                        <i class="far fa-eye"></i>
                                    </button>
                                    <button class="btn btn-warning ml-3"
                                            onclick="window.location.href='<?php echo e(route('admin.motel.getUserMotelAdmin',['id'=>$data->motel->id])); ?>'">
                                        <i class="fas fa-users"></i>
                                    </button>
                                    <form action="<?php echo e(route('admin.invoices.deleteInvoice', $data->id)); ?>" method="POST" class="d-inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" onclick="return confirm('Bạn có chắc muốn xoá gói VIP này không?');" class="btn btn-danger ml-3">
                                            <i class="fas fa-minus-circle"></i></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin_core/content/motel/list.blade.php ENDPATH**/ ?>