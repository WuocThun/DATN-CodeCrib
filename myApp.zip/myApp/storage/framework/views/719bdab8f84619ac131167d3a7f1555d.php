<?php $__env->startSection('main'); ?>

    <main role="main" class="ml-sm-auto col">
        <?php echo $__env->make('admin_core.inc.sub_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

        <div class="container">
            <h1>Báo Cáo Motel</h1>
            <form method="GET" action="#" class="mb-4">
                <div class="row">
                    <div class="col-md-3">
                        <label for="start_date">Ngày bắt đầu:</label>
                        <input type="date" id="start_date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="end_date">Ngày kết thúc:</label>
                        <input type="date" id="end_date" name="end_date" class="form-control" value="<?php echo e(request('end_date')); ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="motel_id">Chọn Motel:</label>
                        <select id="motel_id" name="motel_id" class="form-control">
                            <option value="">Tất cả Motel</option>
                            <?php $__currentLoopData = $allMotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($motel->id); ?>" <?php echo e(request('motel_id') == $motel->id ? 'selected' : ''); ?>>
                                    <?php echo e($motel->name); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-3 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary w-100">Lọc Báo Cáo</button>
                    </div>
                </div>
            </form>
            <!-- Tổng thu nhập từ các hóa đơn -->
            <div class="card mb-4">
                <div class="card-header">
                    <strong>Tổng thu nhập từ các hóa đơn</strong>
                </div>
                <div class="card-body">
                    <p>Tổng tiền phải trả: <?php echo e(number_format($totalAmount, 0, ',', '.')); ?> VNĐ</p>
                    <p>Tổng tiền điện: <?php echo e(number_format($totalElectric, 0, ',', '.')); ?> VNĐ</p>
                    <p>Tổng tiền nước: <?php echo e(number_format($totalWater, 0, ',', '.')); ?> VNĐ</p>

                    <!-- Biểu đồ thu nhập từ hóa đơn -->
                    <canvas id="invoiceChart"></canvas>
                </div>
            </div>

            <!-- Thống kê tổng thu nhập từ các Motel -->
            <div class="card mb-4">
                <div class="card-header">
                    <strong>Tổng thu nhập từ Motel</strong>
                </div>
                <div class="card-body">
                    <p>Tổng tiền phòng: <?php echo e(number_format($totalMotelIncome, 0, ',', '.')); ?> VNĐ</p>
                    <p>Tổng tiền điện: <?php echo e(number_format($totalElectric, 0, ',', '.')); ?> VNĐ</p>
                    <p>Tổng tiền nước: <?php echo e(number_format($totalWater, 0, ',', '.')); ?> VNĐ</p>
                    <p>Tổng tiền wifi: <?php echo e(number_format($totalWifiIncome, 0, ',', '.')); ?> VNĐ</p>
                    <p>Tổng các khoản phí khác: <?php echo e(number_format($totalOtherIncome, 0, ',', '.')); ?> VNĐ</p>

                    <!-- Biểu đồ thu nhập từ các Motel -->
                    <canvas id="motelChart"></canvas>
                </div>
            </div>

            <!-- Danh sách các Motel của người dùng -->
            <div class="card mb-4">
                <div class="card-header">
                    <strong>Danh sách Motel</strong>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Tên Motel</th>
                            <th>Loại Motel</th>
                            <th>Tổng Thành Viên</th>
                            <th>Thu Nhập Từ Phòng</th>
                            <th>Thu Nhập Từ Điện</th>
                            <th>Thu Nhập Từ Nước</th>
                            <th>Thu Nhập Từ Wifi</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $motels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $motel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($motel->name); ?></td>
                                <td><?php echo e($motel->kind_motel); ?></td>
                                <td><?php echo e($motel->total_member); ?></td>
                                <td><?php echo e(number_format($motel->money, 0, ',', '.')); ?> VNĐ</td>
                                <td><?php echo e(number_format($motel->money_electric, 0, ',', '.')); ?> VNĐ</td>
                                <td><?php echo e(number_format($motel->money_water, 0, ',', '.')); ?> VNĐ</td>
                                <td><?php echo e(number_format($motel->money_wifi, 0, ',', '.')); ?> VNĐ</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>

        <script>
            // Biểu đồ thu nhập từ hóa đơn
            var invoiceChartCtx = document.getElementById('invoiceChart').getContext('2d');
            var invoiceChart = new Chart(invoiceChartCtx, {
                type: 'pie',
                data: {
                    labels: ['Tổng tiền phải trả', 'Tổng tiền điện', 'Tổng tiền nước'],
                    datasets: [{
                        label: 'Thu nhập từ hóa đơn',
                        data: [<?php echo e($totalAmount); ?>, <?php echo e($totalElectric); ?>, <?php echo e($totalWater); ?>],
                        backgroundColor: ['#FF5733', '#33FF57', '#3357FF'],
                        borderColor: ['#FF5733', '#33FF57', '#3357FF'],
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(tooltipItem) {
                                    return tooltipItem.label + ': ' + tooltipItem.raw.toLocaleString() + ' VNĐ';
                                }
                            }
                        }
                    }
                }
            });

            // Biểu đồ thu nhập từ các Motel
            var motelChartCtx = document.getElementById('motelChart').getContext('2d');
            var motelChart = new Chart(motelChartCtx, {
                type: 'bar',
                data: {
                    labels: ['Tổng tiền phòng', 'Tổng tiền điện', 'Tổng tiền nước', 'Tổng tiền wifi', 'Các khoản phí khác'],
                    datasets: [{
                        label: 'Thu nhập từ Motel',
                        data: [<?php echo e($totalAmount); ?>, <?php echo e($totalElectric); ?>, <?php echo e($totalWater); ?>, <?php echo e($totalWifiIncome); ?>, <?php echo e($totalOtherIncome); ?>],
                        backgroundColor: '#3498db',
                        borderColor: '#2980b9',
                        borderWidth: 1
                    }]
                },
                options: {
                    responsive: true,
                    plugins: {
                        legend: {
                            position: 'top',
                        },
                        tooltip: {
                            callbacks: {
                                label: function(tooltipItem) {
                                    return tooltipItem.label + ': ' + tooltipItem.raw.toLocaleString() + ' VNĐ';
                                }
                            }
                        }
                    }
                }
            });
        </script>    </main>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin_core/content/motel/report.blade.php ENDPATH**/ ?>