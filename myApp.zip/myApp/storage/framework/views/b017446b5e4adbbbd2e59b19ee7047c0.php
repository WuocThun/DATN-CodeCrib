<?php $__env->startSection('title','Quên mật khẩu'); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('fe.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <form method="POST" action="<?php echo e(route('password.update')); ?>">
        <?php echo csrf_field(); ?>
        <h1 class="text-lg font-bold mb-4">Đặt lại mật khẩu</h1>

        <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">

        <div>
            <label for="email">Email:</label>
            <input id="email" type="email" name="email" value="<?php echo e(old('email', $request->email)); ?>" required class="block mt-1 w-full">
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-red-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mt-4">
            <label for="password">Mật khẩu mới:</label>
            <input id="password" type="password" name="password" required class="block mt-1 w-full">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <span class="text-red-500"><?php echo e($message); ?></span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="mt-4">
            <label for="password_confirmation">Xác nhận mật khẩu:</label>
            <input id="password_confirmation" type="password" name="password_confirmation" required class="block mt-1 w-full">
        </div>

        <div class="mt-4">
            <button type="submit" class="btn-primary">Đặt lại mật khẩu</button>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('overView'); ?>
    <?php echo $__env->make('fe.inc.over_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('fe.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fe.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/auth/reset-password.blade.php ENDPATH**/ ?>