

<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="/">Trang chủ</a>


    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
                <a class="nav-link active" href="<?php echo e(route('admin.index')); ?>">Trang chủ quản lý <span class="sr-only">(current)</span></a>
            </li>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
            <li class="nav-item active">
                <a class="nav-link active" href="<?php echo e(route('admin.rooms_classification.index')); ?>">Danh mục phòng <span class="sr-only">(current)</span></a>
            </li>
            <?php endif; ?>
            <div class="dropdown">
                <a class="btn  dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Danh sách Blog
                </a>
                <ul class="dropdown-menu">
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('admin.blogs.index')); ?>">Tât cả blogs</a></li>
                    <?php endif; ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('admin.blogs.myblogs')); ?>">Bài viết của tôi</a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage blogs')): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.get_pending_blogs')); ?>">Duyệt bài Blogs</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="dropdown">
                <a class="btn  dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Đăng Phòng
                </a>
                <ul class="dropdown-menu">
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('admin.rooms.allRooms')); ?>">Tất cả các phòng hiện có - (admin)</a></li>
                    <?php endif; ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('admin.rooms.myRooms')); ?>">Phòng của tôi</a></li>
                    <li><a class="dropdown-item" href="<?php echo e(route('admin.rooms.create')); ?>">Đăng bài phòng</a></li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage blogs')): ?>
                        <li><a class="dropdown-item" href="<?php echo e(route('admin.rooms.getPendingRooms')); ?>">Tất cả bài cần duyệt</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="dropdown">
                <a class="btn  dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Nạp tiền vào tài khoản
                </a>
                <ul class="dropdown-menu">
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('admin.rooms.allRooms')); ?>">Kiểm tra toàn hệ thống (admin) --chưa update</a></li>
                    <?php endif; ?>
                    <li><a class="dropdown-item" href="<?php echo e(route('admin.user.paymentIndex')); ?>">Nạp tiền</a></li>
                    <li><a class="dropdown-item" href="<?php echo e(route('admin.payment.historyPayment')); ?>">Lịch sử nạp tiền</a></li>





                </ul>
            </div>
        </ul>
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
        <div class="dropdown">
            <a class="btn  dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                Toàn quyền
            </a>

            <ul class="dropdown-menu">
                <li><a class="dropdown-item" href="<?php echo e(route('admin.allUser')); ?>">Tất cả người dùng</a></li>
                <li><a class="dropdown-item" href="<?php echo e(route('admin.addRole')); ?>">Gỡ vai trò</a></li>
            </ul>
        </div>
        <?php endif; ?>


    </div>
</nav>
<?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin/inc/navbar.blade.php ENDPATH**/ ?>