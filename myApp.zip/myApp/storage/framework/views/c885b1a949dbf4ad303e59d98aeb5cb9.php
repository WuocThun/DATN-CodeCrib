<section class="search-bar">
    <div class="container search-container">
        <input type="hidden" id="room_class" hidden="" value="<?php echo $cl->title ?? ''; ?>" />
        <select class="bus_to_input" id="romm_class_to_input">
            <option></option>
            <?php $__currentLoopData = $clasRoom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class => $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cl->id); ?>" data-name="<?php echo e($cl->title); ?>"><?php echo e($cl->title); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <select name="province" id="province-select">
            <option></option>
        <?php $__currentLoopData = $provinceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($data['province_id']); ?>"><?php echo e($data['province_name']); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <select name="gia" id="price-select">

            <!-- Các lựa chọn giá ở đây -->
        </select>

        <select name="dien-tich" id="area-select">





            <!-- Các lựa chọn diện tích ở đây -->
        </select>

        <button id="bar_search" class="search-btn">Tìm kiếm</button>

        <!-- Div to display search results -->
        <div id="search-results"></div>


</section>
<script>
    document.getElementById('bar_search').addEventListener('click', function() {
        // Lấy giá trị các trường dropdown
        var roomClass = document.getElementById('romm_class_to_input').value || ''; // Nếu không có giá trị thì là chuỗi rỗng
        var provinceId = document.getElementById('province-select').value || '';   // Nếu không có giá trị thì là chuỗi rỗng
        var price = document.getElementById('price-select').value || '';           // Nếu không có giá trị thì là chuỗi rỗng
        var area = document.getElementById('area-select').value || '';             // Nếu không có giá trị thì là chuỗi rỗng

        // Tạo dữ liệu để gửi trong request, chỉ gửi các giá trị đã chọn
        var data = {};

        // Kiểm tra và thêm vào đối tượng `data` nếu có giá trị
        if (roomClass !== '') {
            data.room_class = roomClass;
        }
        if (provinceId !== '') {
            data.province_id = provinceId;
        }
        if (price !== '') {
            data.price = price;
        }
        if (area !== '') {
            data.area = area;
        }

        // Tạo URL với tham số tìm kiếm
        var queryString = new URLSearchParams(data).toString();
        var searchUrl = '/tim-kiem/phong?' + queryString;

        // Chuyển hướng tới trang kết quả tìm kiếm với query string
        window.location.href = searchUrl;
    });
</script>
<?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/fe/inc/search_bar.blade.php ENDPATH**/ ?>