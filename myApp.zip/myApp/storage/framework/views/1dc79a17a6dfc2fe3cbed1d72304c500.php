<?php $__env->startSection('main'); ?>
    <div class=" container  mt-4">
        <!-- Lọc ngày -->
        <div class="row justify-content-center mb-4">
            <div class="col-md-12">
                <form action="" method="GET">
                    <div class="row">
                        <div class="col-md-4">
                            <label for="start_date" class="form-label">Ngày bắt đầu:</label>
                            <input type="date" id="start_date" name="start_date" class="form-control"
                                   value="<?php echo e(request()->input('start_date')); ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="end_date" class="form-label">Ngày kết thúc:</label>
                            <input type="date" id="end_date" name="end_date" class="form-control"
                                   value="<?php echo e(request()->input('end_date')); ?>">
                        </div>
                        <div class="col-md-4 d-flex align-items-end">
                            <button type="submit" class="btn btn-primary w-100">Lọc</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Thống kê tổng quan -->
        <div class="card">
            <div class="card-header">
                <h3>Thống kê tổng quan về website</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <!-- Các thông tin thống kê -->
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Số lượng bài viết</h5>
                                <p class="card-text"><?php echo e($statistics['blog_count']); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Số lượng người dùng</h5>
                                <p class="card-text"><?php echo e($statistics['user_count']); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Số lượng phòng đang hoạt động</h5>
                                <p class="card-text"><?php echo e($statistics['active_room_count']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Các thông tin thống kê tiếp theo -->
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Số lượng hợp đồng</h5>
                                <p class="card-text"><?php echo e($statistics['contract_count']); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Số lượng hợp đồng đang hoạt động</h5>
                                <p class="card-text"><?php echo e($statistics['active_contract_count']); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Số lượng phòng</h5>
                                <p class="card-text"><?php echo e($statistics['room_count']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Các thông tin thống kê tiếp theo -->
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Số lượng công việc thất bại</h5>
                                <p class="card-text"><?php echo e($statistics['failed_job_count']); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Số lượng hóa đơn</h5>
                                <p class="card-text"><?php echo e($statistics['invoice_count']); ?></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card shadow-sm">
                            <div class="card-body">
                                <h5 class="card-title">Số lượng hóa đơn đang chờ xử lý</h5>
                                <p class="card-text"><?php echo e($statistics['pending_invoice_count']); ?></p>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Tổng thu nhập -->
                <h3>Tổng Quan</h3>
                <ul>
                    <li><strong>Tổng thu nhập:</strong> <?php echo e(number_format($statistics['total_income'], 0, ',', '.')); ?>

                        VND
                    </li>
                </ul>

                <!-- Biểu đồ thu nhập hàng tháng -->
                <div class="row">
                    <div class="col-md-12">
                        <canvas id="monthly-income-chart" width="400" height="200"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <!-- Danh sách người dùng -->
        <div class="mt-4">
            <h3>Danh Sách Người Dùng</h3>
            <table class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên</th>
                    <th>Email</th>
                    <th>VIP</th>
                    <th>Ngày Tham Gia</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $statistics['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->is_vip ? 'Có' : 'Không'); ?></td>
                        <td><?php echo e(\Carbon\Carbon::parse($user->created_at)->format('d/m/Y')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Danh sách phòng đang hoạt động -->
        <div class="mt-4">
            <h3>Danh Sách Phòng Đang Hoạt Động</h3>
            <table class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tiêu Đề</th>
                    
                    <th>Giá</th>
                    <th>Ngày Đăng</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $statistics['active_rooms']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($room->id); ?></td>
                        <td><?php echo e($room->title); ?></td>
                        <?php $__currentLoopData = $allProvinceData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $provider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <?php if($room->province ==$provider['province_id']  ): ?>
                                <td><?php echo e($provider['province_name']); ?></td>
                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e(number_format($room->price, 0, ',', '.')); ?> VND</td>
                        <td><?php echo e(\Carbon\Carbon::parse($room->created_at)->format('d/m/Y')); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>

            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('monthly-income-chart').getContext('2d');
        const chart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($chartData['labels']); ?>,
                datasets: [
                    {
                        label: 'Tổng thu nhập hàng tháng',
                        data: <?php echo json_encode($chartData['data']); ?>,
                        backgroundColor: [
                            'rgba(255, 99, 132, 0.2)',
                            'rgba(54, 162, 235, 0.2)',
                            'rgba(255, 206, 86, 0.2)',
                            'rgba(75, 192, 192, 0.2)',
                            'rgba(153, 102, 255, 0.2)',
                            'rgba(255, 159, 64, 0.2)',
                        ],
                        borderColor: [
                            'rgba(255, 99, 132, 1)',
                            'rgba(54, 162, 235, 1)',
                            'rgba(255, 206, 86, 1)',
                            'rgba(75, 192, 192, 1)',
                            'rgba(153, 102, 255, 1)',
                            'rgba(255, 159, 64, 1)',
                        ],
                        borderWidth: 1,
                    },
                ],
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true,
                    },
                },
            },
        });
    </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin_core/content/system/statistics.blade.php ENDPATH**/ ?>