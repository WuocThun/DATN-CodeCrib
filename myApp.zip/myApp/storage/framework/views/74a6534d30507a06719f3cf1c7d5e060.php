<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin_core.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <main role="main" class="ml-sm-auto col">

        <?php echo $__env->make('admin_core.inc.sub_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div
            class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pb-2 mb-3 border-bottom">
            <h1 class="h2">Nạp tiền vào tài khoản</h1>
        </div>
        <div class="row">
            <div class="col-md-12">
                <h3 class=" mb-3">Mời bạn chọn phương thức nạp tiền</h3>
                <div class="list-group dashboard_list_payment_method d-md-none">
                </div>
                <div class="d-none d-md-block">
                    <div class="row  addfund_method_listclearfix ">
                        <div class="col-md-3">
                        <div class="method_item">
                            <a href="<?php echo e(route('admin.payment.mbbank')); ?>">
                                <div class="method_item_icon">
                                    <img width="200px" class="img-thumbnail" src="<?php echo e(asset('uploads/payment/payment-transfer.png')); ?>" alt="Chuyển khoản trực tiếp"
                                         title="Chuyển khoản trực tiếp">
                                </div>
                                <div class="method_item_name">
                                    Thanh toán qua MbBank
                                </div>
                                <button class="btn btn_select_method">Chọn</button>
                            </a>
                        </div>
                        </div>
                        <div class="method_item">
                            <a href="<?php echo e(route('admin.vnpay')); ?>">
                                <div class="method_item_icon">
                                    <img width="200px" class="img-thumbnail" src="<?php echo e(asset('uploads/payment/vnpay.png')); ?>" alt="Chuyển khoản trực tiếp"
                                         title="Chuyển khoản trực tiếp">
                                </div>
                                <div class="method_item_name">
                                    Thanh toán qua VNPAY
                                </div>
                                <button class="btn btn_select_method">Chọn</button>
                            </a>
                        </div>
                        </div>





























































































                    </div>
                </div>
            </div>

        </div>


        <br><br>

    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/myApp/resources/views/admin_core/content/payments/index.blade.php ENDPATH**/ ?>