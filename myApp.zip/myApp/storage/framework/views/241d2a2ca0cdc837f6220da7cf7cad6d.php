
<nav class="d-none d-lg-block bg-light sidebar">
    <div class="user_info">
        <a href="#" class="clearfix">
            <div class="center">
                <img class="img-fluid" src="<?php echo e(asset('uploads/logoCodeCrib.png')); ?>">


</div>
            <div class="user_meta">
                <div class="inner">
                    <div class="user_name"><?php echo e(Auth::user()->name); ?></div>
                    <div class="user_verify" style="color: #555; font-size: 0.9rem;"><?php echo e(Auth::user()->phone_number); ?></div>
                </div>
            </div>
        </a>
        <ul>
            <li><span>Mã thành viên:</span> <span style="font-weight: 700;"> <?php echo e(Auth::user()->id); ?></span></li>
            <li><span>TK Chính:</span> <span style="font-weight: 700;"> <?php echo e(number_format(Auth::user()->balance, 0, ',', '.')); ?></span></li>

        </ul>
        <div class="row">
            <div class="col">
                <a class="btn btn-warning" href="<?php echo e(route('admin.trangChuNapThe')); ?>">Nạp
                    tiền</a>
            </div>
            <div class="col">

                <a class="btn btn-danger" href="<?php echo e(route('admin.roomsCore.createCore')); ?>">Đăng
                    tin</a>
            </div>
        </div>
    </div>
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
    <div class="dropdown mb-1">
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
        Quản lý
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <li><a class="dropdown-item" href="#">Quản lý tất cả các phòng tin</a></li>
            <li><a class="dropdown-item" href="#">Quản lý tất cả người dùng</a></li>
            <li><a class="dropdown-item" href="#">Quản lý tất cả báo cáo</a></li>
            <li><a class="dropdown-item" href="#">Thống kê doanh thu</a></li>
        </ul>
    </div>
    <?php endif; ?>
    <div class="dropdown mb-1" >
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            Quản lý các bài đăng
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <li><a class="dropdown-item" href="<?php echo e(route('admin.roomsCore.createCore')); ?>">Đăng tin mới</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('admin.phongcuatoi')); ?>">Các tin đã đăng</a></li>
            <li><a class="dropdown-item" href="#">Các tin đang đợi duyệt</a></li>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
            <li><a class="dropdown-item" href="#">Tất cả các phòng hiện có</a></li>
            <?php endif; ?>
        </ul>
    </div>
    <div class="dropdown mb-1" >
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            Nạp tiền
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <li><a class="dropdown-item" href="#">Nạp tiền</a></li>
            <li><a class="dropdown-item" href="#">Lịch sử nạp tiền</a></li>
            <li><a class="dropdown-item" href="#">Lịch sử thanh toán</a></li>
        </ul>
    </div>
    <div class="dropdown mb-1" >
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            Sự kiện
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <li><a class="dropdown-item" href="<?php echo e(route('admin.wheel.index')); ?>">Vòng quay may mắn</a></li>
        </ul>
    </div>
    <div class="dropdown mb-1" >
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            Quản lý phòng trọ
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <li><a class="dropdown-item" href="<?php echo e(route('admin.motel.index')); ?>">Danh sách trọ của bạn</a></li>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'houseRenter||admin')): ?>
            <li><a class="dropdown-item" href="<?php echo e(route('admin.motel.index')); ?>">Danh sách các phòng trọ</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('admin.invoices.getIndexInvoice')); ?>">Danh sách các hoá đơn</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('admin.invoices.motelReport')); ?>">Báo cáo</a></li>
            <li><a class="dropdown-item" href="#">Lịch sử thanh toán</a></li>
            <?php endif; ?>

        </ul>
    </div>
    <div class="dropdown mb-1" >
        <a class="btn btn-secondary dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-bs-toggle="dropdown" aria-expanded="false">
            Người dùng
        </a>
        <ul class="dropdown-menu" aria-labelledby="dropdownMenuLink">
            <li><a class="dropdown-item" href="#">Chỉnh sửa tài khoản</a></li>
            <li>
                <a class="dropdown-item" href="#"
                   onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                    Đăng xuất
                </a>
                <form id="logout-form" method="POST" action="<?php echo e(route('logout')); ?>" style="display: none;">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        </ul>

    </div>






























































































































</nav>









<?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin_core/inc/navbar.blade.php ENDPATH**/ ?>