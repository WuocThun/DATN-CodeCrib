<?php $__env->startSection('main'); ?>

    <!-- Thông báo -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Thống kê User')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 bg-white border-b border-gray-200">

                    <h3 class="text-lg font-medium">Tổng quan</h3>
                    <ul>
                        <li><strong>Tổng số lượng User:</strong> <?php echo e($totalUsers); ?></li>
                        <li><strong>Số lượng User VIP:</strong> <?php echo e($vipUsers); ?></li>
                        <li><strong>Số dư trung bình:</strong> <?php echo e(number_format($averageBalance, 0, ',', '.')); ?> VNĐ
                        </li>
                        <li><strong>Số lượng User có số dư lớn hơn 100.000:</strong> <?php echo e($usersWithHighBalance); ?></li>
                        <li><strong>Số lượng User đã có trọ:</strong> <?php echo e($usersWithMotel); ?></li>
                        <li><strong>Số lượng User chưa có trọ:</strong> <?php echo e($usersWithoutMotel); ?></li>
                    </ul>

                    <h3 class="text-lg font-medium mt-6">Biểu đồ User theo tháng</h3>
                    <canvas id="userChart" width="400" height="200"></canvas>

                </div>
            </div>
        </div>
    </div>

    <!-- Bảng Danh Sách Người Dùng -->
    <div class="container mt-5">
        <h1 class="text-center mb-4">Danh sách User</h1>

        <!-- Thêm các link sắp xếp -->
        <div class="mb-3">
            <a href="<?php echo e(route('admin.user.report', ['sort_by' => 'balance', 'order' => 'desc'])); ?>"
               class="btn btn-primary">Sắp xếp theo số dư (Từ cao đến thấp)</a>
            <a href="<?php echo e(route('admin.user.report', ['sort_by' => 'created_at', 'order' => 'asc'])); ?>"
               class="btn btn-secondary">Sắp xếp theo ngày tạo (Cũ đến mới)</a>
            <a href="<?php echo e(route('admin.user.report', ['sort_by' => 'created_at', 'order' => 'desc'])); ?>"
               class="btn btn-success">Sắp xếp theo ngày tạo (Mới đến cũ)</a>
        </div>

        <!-- Bảng thông tin người dùng -->
        <table class="table table-striped table-bordered">
            <thead class="table-dark">
            <tr>
                <th>Mã số tài khoản</th>
                <th>Tên</th>
                <th>Email</th>
                <th>Số điện thoại</th>
                <th>Số dư</th>
                <th>Đã có trọ?</th>
                <th>Tên của chủ trọ</th>
                <th>Hành động</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($user->rand_code_user); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->phone_number); ?></td>
                    <td><?php echo e(number_format($user->balance,0, ',', '.')); ?> VNĐ</td>
                    <td><?php echo e($user->motel_id ? 'Đã có trọ - ' : 'Chưa có trọ'); ?> <?php echo e($user->motel->name ?? ''); ?> </td>
                    <td>
                        Chủ trọ: <?php echo e($user->owner_name ?? 'Chưa đăng ký trọ'); ?>

                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.users.edit', [$user->id])); ?>" class="btn btn-warning">Sửa</a>
                        <form action="<?php echo e(route('admin.users.delete', $user->id)); ?>" method="POST"
                              onsubmit="return confirm('Bạn có chắc chắn muốn xóa người dùng này không?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm">Xóa</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Pagination -->
        <div class="pagination">
            <?php if($users->onFirstPage()): ?>
                <button class="prev" disabled>« Trang trước</button>
            <?php else: ?>
                <a href="<?php echo e($users->previousPageUrl()); ?>" class="prev">« Trang trước</a>
            <?php endif; ?>

            <?php for($page = 1; $page <= $users->lastPage(); $page++): ?>
                <a href="<?php echo e($users->url($page)); ?>"
                   class="page <?php echo e($page == $users->currentPage() ? 'active' : ''); ?>"><?php echo e($page); ?></a>
            <?php endfor; ?>

            <?php if($users->hasMorePages()): ?>
                <a href="<?php echo e($users->nextPageUrl()); ?>" class="next">Trang sau »</a>
            <?php else: ?>
                <button class="next" disabled>Trang sau »</button>
            <?php endif; ?>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const ctx = document.getElementById('userChart').getContext('2d');
            const userChart = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: <?php echo json_encode($chartLabels, 15, 512) ?>,
                    datasets: [
                        {
                            label: 'Số lượng User',
                            data: <?php echo json_encode($chartData, 15, 512) ?>,
                        backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        borderColor: 'rgba(75, 192, 192, 1)',
                        borderWidth: 1
                    }]
                },
                options: {
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    },
                    plugins: {
                        legend: {
                            display: true,
                            position: 'top'
                        },
                        title: {
                            display: true,
                            text: 'Thống kê User theo tháng'
                        }
                    }
                }
            });
        });
    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin_core/content/users/user-report.blade.php ENDPATH**/ ?>