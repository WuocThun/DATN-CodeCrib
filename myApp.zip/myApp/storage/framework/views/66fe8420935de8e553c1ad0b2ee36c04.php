<?php $__env->startSection('title','Chi tiết bài viết'); ?>
<?php $__env->startSection('header'); ?>
    <?php echo $__env->make('fe.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <style>
        .results-left {
            width: 70%; /* 70% for the left column */
            padding: 20px;
            border: 0.5px #b1adad solid;
        }
        .results-left h1 {
            font-size: 24px;
            font-weight: bold;
            text-align: left;
            color: #333;
            line-height: 1.4;
            margin-bottom: 20px;
        }

        .article-summary p {
            font-size: 16px;
            line-height: 1.6;
            color: #555;
            margin-bottom: 20px;
        }

        .article-main-content figure {
            margin: 20px 0;
            text-align: center;
        }

        .article-main-content figure img {
            max-width: 100%;
            height: auto;
        }

        .article-main-content h2 {
            font-size: 20px;
            margin: 20px 0;
            color: #333;
        }

        .article-main-content h3 {
            font-size: 18px;
            margin: 15px 0;
            font-style: italic;
            color: #444;
        }

        .article-main-content p {
            font-size: 16px;
            line-height: 1.6;
            margin-bottom: 15px;
            color: #555;
        }

        .article-tags {
            margin-top: 30px;
            padding: 10px 0;
            border-top: 1px solid #ddd;
        }

        .article-tags span {
            font-weight: bold;
            margin-right: 10px;
        }

        .tags-content span {
            display: inline-block;
            background-color: #eee;
            padding: 5px 10px;
            border-radius: 5px;
            color: #333;
        }
    </style>

    <section class="search-results">
        <div class="container search-results-container">
            <div class="results-left">
                <div>
                    <h1 class="text-2xl">Chi tiết tin:
                        <?php echo e($blog->title); ?>

                    </h1>

                    <div>

                    </div>
                    <div class="article-summary">
                        <?php echo e($blog->content); ?>

                    </div>
                    <div class="article-main-content">
                        <figure style="text-align: center">
                            <img
                                src="<?php echo e(asset('uploads/blogs/'.$blog->image)); ?>"
                                alt=<?php echo e($blog->title); ?>

                  width="960"
                                height="720"
                            />
                            <figcaption>
                                <em
                                ><?php echo e($blog->title); ?></em
                                >
                            </figcaption>
                        </figure>
                        <?php
                            echo ($blog->description)
                        ?>
                    </div>
                    
                    
                    
                    
                </div>

            </div>
            <?php echo $__env->make('fe.inc.fitler_blogs_right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('overView'); ?>
    <?php echo $__env->make('fe.inc.over_view', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?>
    <?php echo $__env->make('fe.inc.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('fe.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/fe/baiviet.blade.php ENDPATH**/ ?>