<?php $__env->startSection('main'); ?>

<?php if(session('success')): ?>
    <div class="alert alert-success">
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>
<div class="container">
<!-- Bảng danh sách tiện ích -->
<table class="table table-striped">
    <thead>
    <tr>
        <th scope="col">#</th>
        <th scope="col">Tên Tiện Ích</th>
        <th scope="col">Mô Tả</th>
        <th scope="col">Icon</th>
        <th scope="col">Hành Động</th>
    </tr>
    </thead>
    <tbody>
    <?php $__currentLoopData = $utilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $utility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th scope="row"><?php echo e($utility->id); ?></th>
            <td><?php echo e($utility->name); ?></td>
            <td><?php echo e($utility->description); ?></td>
            <td><i class="<?php echo e($utility->icon); ?>"></i></td>
            <td>
                <!-- Hành động như chỉnh sửa, xóa có thể thêm vào đây -->
                <a href="<?php echo e(route('admin.utilities.edit',$utility->id)); ?>" class="btn btn-warning btn-sm">Sửa</a>
                <form action="<?php echo e(route('admin.utilities.destroy', $utility->id)); ?>" method="POST" style="display: inline;">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc chắn muốn xóa tiện ích này?')">Xóa</button>
                </form>            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<a href="<?php echo e(route('admin.utilities.create')); ?>" class="btn btn-success">Thêm Tiện Ích Mới</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin_core/content/utility/index.blade.php ENDPATH**/ ?>