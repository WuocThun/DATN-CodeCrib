<?php $__env->startSection('main'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Danh sách tất cả người dùng</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                        <a href="<?php echo e(route('admin.user.create')); ?>" class="btn btn-success"> Thêm người dùng </a>
                        <table class="table table-striped table-responsive">
                            <thead>
                            <tr>
                                <table id="myTable" class="table">
                                    <thead>
                                    <th scope="col">ID</th>
                                    <th scope="col">Tên User</th>
                                    <th scope="col">Email</th>
                                    
                                    <th scope="col">Vai trò (roles)</th>
                                    <th scope="col">Quyền (permission)</th>
                                    <th scope="col">Quản lý</th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th><?php echo e($us->id); ?></th>
                                            <th><?php echo e($us->name); ?></th>
                                            <th><?php echo e($us->email); ?></th>
                                            <th>
                                                <?php $__currentLoopData = $us->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key1 => $roles): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge bg-info"><?php echo e($roles->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </th>
                                            <th>
                                                <?php $__currentLoopData = $roles->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <span class="badge bg-warning text-dark"><?php echo e($permissions->name); ?></span>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </th>
                                            <th>
                                                <a href="<?php echo e(route('admin.assgin',$us->id)); ?>" class="btn btn-warning">Phân
                                                    vai trò</a>
                                                <a href="<?php echo e(route('admin.permission',$us->id)); ?>" class="btn btn-success">Phân
                                                    thêm quyền</a>
                                                <form method="post"  action="<?php echo e(route('admin.users.delete',[$us->id])); ?>">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button onclick="return confirm('Bạn có muốn xoá?')" class="btn btn-danger">Xoá</button>
                                                </form>
                                            </th>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                </th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/tetsFunctionCodeCrib/myApp/resources/views/admin/content/permissions/index.blade.php ENDPATH**/ ?>