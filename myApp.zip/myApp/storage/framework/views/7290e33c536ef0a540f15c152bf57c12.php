<?php $__env->startSection('main'); ?>
    <main role="main" class="ml-sm-auto col">

        <?php echo $__env->make('admin_core.inc.sub_main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="container mt-5">
            <h1 class="mb-4">Danh sách góp ý</h1>
            <table class="table table-bordered table-striped">
                <thead>
                <tr>
                    <th>ID</th>
                    <th>Tên</th>
                    <th>Số sao</th>
                    <th>Rating</th>
                    <th>Nội dung</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($review->id); ?></td>
                        <td><?php echo e($review->name); ?></td>
                        <td><?php echo e($review->email); ?></td>
                        <td><?php echo e($review->rating); ?></td>

                        <td><?php echo e($review->comment); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin_core/content/reviews/index.blade.php ENDPATH**/ ?>