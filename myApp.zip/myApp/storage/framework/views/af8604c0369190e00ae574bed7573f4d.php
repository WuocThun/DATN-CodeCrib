<?php $__env->startSection('main'); ?>
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Danh Sách Phòng</div>

                    <div class="card-body">
                        <?php if(session('status')): ?>
                            <div class="alert alert-success" role="alert">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>

                        <a href="<?php echo e(route('admin.roomsCore.createCore')); ?>" class="btn btn-success"> Thêm tin phòng mới </a>
                        <table class="table">
                            <thead>
                            <tr>
                                <table id="myTable" class="table">
                                    <thead>
                                    <th scope="col">ID</th>
                                    <th scope="col">Tên Phòng</th>
                                    <th scope="col">Gói Vip</th>
                                    <th scope="col">Trạng thái</th>
                                    <th scope="col">Ngày đăng</th>
                                    <th scope="col">Hình ảnh</th>
                                    <th scope="col">Hành động</th>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $room; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key =>$myroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <tr>
                                           <td><?php echo e($myroom->id); ?></td>
                                           <td><?php echo e($myroom->title); ?></td>

                                           <td class="btn align-middle"><?php echo e($myroom->vipPackage ? $myroom->vipPackage->name : 'Không có gói VIP'); ?></td> <!-- Hiển thị tên gói VIP -->
                                           <td>
                                           <?php if($myroom->status == 1): ?>
                                               <p class="text-success btn">Phòng đã được duyệt </p>
                                           <?php elseif($myroom->status == 0): ?>

                                                   <p class="text-warning btn">Phòng đang đợi QTV duyệt</p>
                                           <?php elseif($myroom->status == 3): ?>
                                               <p class="text-danger btn">Phòng đã bị từ chối</p>
                                           <?php else: ?>
                                                   <p class="text-danger btn">Phòng Không hiển thị </p>
                                           <?php endif; ?>
                                           </td>
                                           <td><?php echo e($myroom->created_at); ?></td>
                                           <td>
                                               <?php
                                                   // Decode the JSON data for images
                                                   $images = json_decode($myroom->image, true);
                                               ?>

                                               <?php if(!empty($images)): ?>
                                                   <?php if(count($images) === 1): ?>
                                                       <!-- Display a single image -->
                                                       <img width="200px" height="100px" src="<?php echo e(asset('uploads/rooms/' . json_decode( $myroom->image))); ?>" alt="Room Image">
                                                   <?php else: ?>
                                                       <!-- Bootstrap Carousel for Multiple Images -->
                                                       <div id="carousel-<?php echo e($myroom->id); ?>" class="carousel slide" data-bs-ride="carousel">
                                                           <div class="carousel-inner">
                                                               <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                   <div class="carousel-item <?php echo e($index == 0 ? 'active' : ''); ?>">
                                                                       <img width="200px" height="100px" src="<?php echo e(asset('uploads/rooms/' . $img)); ?>" alt="Room Image">
                                                                   </div>
                                                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                           </div>
                                                           <!-- Controls -->
                                                           <button class="carousel-control-prev" type="button" data-bs-target="#carousel-<?php echo e($myroom->id); ?>" data-bs-slide="prev">
                                                               <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                                                               <span class="visually-hidden">Previous</span>
                                                           </button>
                                                           <button class="carousel-control-next" type="button" data-bs-target="#carousel-<?php echo e($myroom->id); ?>" data-bs-slide="next">
                                                               <span class="carousel-control-next-icon" aria-hidden="true"></span>
                                                               <span class="visually-hidden">Next</span>
                                                           </button>
                                                       </div>
                                                   <?php endif; ?>
                                               <?php else: ?>
                                                   <p>No images available</p>
                                               <?php endif; ?>
                                           </td>
                                           <td>












































<!-- Nút Mua VIP -->
                                               <a class="btn btn-warning"  href="<?php echo e(route('admin.rooms.edit',$myroom->id)); ?>">Sửa</a>

                                               <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($myroom->id); ?>">
                                                   Mua VIP
                                               </button>

                                               <!-- Modal -->
                                               <div class="modal fade" id="exampleModal<?php echo e($myroom->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel<?php echo e($myroom->id); ?>" aria-hidden="true">
                                                   <div class="modal-dialog">
                                                       <div class="modal-content">
                                                           <div class="modal-header">
                                                               <h5 class="modal-title" id="exampleModalLabel<?php echo e($myroom->id); ?>">Thông tin hoá đơn</h5>
                                                               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                           </div>
                                                           <div class="modal-body">
                                                               <div class="container">
                                                                   <?php $__currentLoopData = $vipPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                       <div class="card mb-3">
                                                                           <div class="card-body">
                                                                               <h3 class="card-title"><?php echo e($package->name); ?></h3>
                                                                               <p class="card-text"><strong>Giá:</strong> <?php echo e(number_format($package->price, 0, ',', '.')); ?> VND</p>
                                                                               <p class="card-text"><strong>Thời gian:</strong> <?php echo e($package->duration_days); ?> ngày</p>
                                                                               <p class="card-text"><strong>Lượt xem tăng:</strong> <?php echo e($package->boosted_views); ?></p>

                                                                               <!-- Form để mua gói VIP -->
                                                                               <form action="<?php echo e(route('admin.vip.purchase', [$myroom->id, $package->id])); ?>" method="POST">
                                                                                   <?php echo csrf_field(); ?>
                                                                                   <!-- Truyền room_id và vip_package_id vào form -->
                                                                                   <input type="hidden" name="room_id" value="<?php echo e($myroom->id); ?>">
                                                                                   <input type="hidden" name="vip_package_id" value="<?php echo e($package->id); ?>">
                                                                                   <button type="submit" class="btn btn-primary">Mua Gói</button>
                                                                               </form>
                                                                           </div>
                                                                       </div>
                                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                               </div>
                                                           </div>
                                                           <div class="modal-footer">
                                                               <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                                                               <button type="button" class="btn btn-primary">Lưu thay đổi</button>
                                                           </div>
                                                       </div>
                                                   </div>
                                               </div>


                                               

                                               <form method="post"  action="<?php echo e(route('admin.rooms.destroy',[$myroom->id])); ?>">
                                                   <?php echo method_field('DELETE'); ?>
                                                   <?php echo csrf_field(); ?>
                                                   <button onclick="return confirm('Bạn có muốn xoá?')" class="btn btn-danger">Xoá</button>
                                               </form>
                                           </td>
                                       </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                                </th>
                            </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin/content/rooms/my_room.blade.php ENDPATH**/ ?>