<?php $__env->startSection('navbar'); ?>
    <?php echo $__env->make('admin.inc.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('main'); ?>
    <div class="container">
    <p class="fs-1">Xin chào <?php echo e(Auth::user()->name); ?></p>
        <p>Bạn đang là
        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
            Admin của web
        <?php endif; ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'houseRenter')): ?>
            Admin của web
        <?php endif; ?>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin/inc/index.blade.php ENDPATH**/ ?>