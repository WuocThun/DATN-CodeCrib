<?php $__env->startSection('main'); ?>
    <div class="container mt-5">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <h2 class="mb-4 text-center">Danh Sách Phòng Đã Kích Hoạt Gói VIP</h2>
                <div class="table-responsive">
                    <table class="table table-striped table-hover align-middle">
                        <thead class="table-dark">
                        <tr>
                            <th>Tiêu Đề Phòng</th>
                            <th>Giá (VND)</th>
                            <th>Tỉnh/Thành Phố</th>
                            <th>Địa Chỉ</th>
                            <th>Gói VIP</th>
                            <th>Giá Gói VIP (VND)</th>
                            <th>Ngày Bắt Đầu</th>
                            <th>Ngày Kết Thúc</th>
                            <th>Trạng Thái</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $vipRooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($vip->room->title); ?></td>
                                <td><?php echo e(number_format($vip->room->price)); ?></td>
                                <td><?php echo e($vip->room->province); ?></td>
                                <td><?php echo e($vip->room->full_address); ?></td>
                                <td>
                                    <span class="badge bg-success"><?php echo e($vip->vipPackage->name); ?></span>
                                </td>
                                <td><?php echo e(number_format($vip->vipPackage->price)); ?></td>
                                <td><?php echo e($vip->start_date); ?></td>
                                <td><?php echo e($vip->end_date); ?></td>
                                <td>
                                    <?php if($vip->status === 'active'): ?>
                                        <span class="badge bg-primary">Đang hoạt động</span>
                                        <form action="<?php echo e(route('admin.vipRooms.deactivate', $vip->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Bạn có chắc muốn tắt gói VIP này không?');">
                                                Tắt VIP
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="badge bg-info"><?php echo e(ucfirst($vip->status)); ?></span>
                                    <?php endif; ?>
                                </td>

                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="10" class="text-center text-muted">
                                    Không có phòng nào đang kích hoạt gói VIP.
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_core.layouts.test', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Desktop/DATN/DATN-CodeCrib/myApp/resources/views/admin_core/content/vip/index.blade.php ENDPATH**/ ?>